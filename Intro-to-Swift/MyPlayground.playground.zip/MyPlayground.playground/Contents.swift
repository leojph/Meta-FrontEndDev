import Cocoa

let numberPlate = "WW87GP"
for character in numberPlate {
  print("character is = \(character)")
}
