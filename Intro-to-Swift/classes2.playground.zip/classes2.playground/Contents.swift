import Cocoa

class Product {
    var price : Int = 5
}
var product1 = Product()
var product2 = product1
product1.price = 20
print("\(product1.price) and \(product2.price)")
