import Cocoa

let freeApp = true

if freeApp == true{
    print("You are using the free version of the app. Buy the full version of the app to get access to all of its features.")
}
    
let morningTemp = 70
let eveningTemp = 80

if morningTemp < eveningTemp{
    print("The weather in the morning is colder at \(morningTemp)")
}
else{
    print("The weather in the evening is colder at \(eveningTemp)")
}

let temperatureDegree = "Fahrenheit"
if temperatureDegree == "Fahrenheit"{
    print("The app is using Fahrenheit as degrees")
}
else{
    print("The app is using Celsius as degrees")
}

if temperatureDegree == "Celsius" || temperatureDegree == "Fahrenheit"{
    print("The weather app is configured properly.")
}
else{
    print("The weather app is not configured properly.")
}

switch temperatureDegree {
    case "Fahrenheit": print("The weather app is configured for the US.")
    case "Celsius": print("The weather app is configured for Europe.")
    default: print("The weather app has an unknown configuration.")
}
