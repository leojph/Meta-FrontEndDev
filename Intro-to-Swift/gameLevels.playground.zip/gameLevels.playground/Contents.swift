import Cocoa

var levelScores:[Int] = []

if levelScores.count == 0{
    print("Welcome to the game!")
}

let firstLvlScore = 10
levelScores.append(firstLvlScore)

print("The first level's score is \(levelScores[0]) ")

let lvlBonus = 40
levelScores[0] += lvlBonus
print("The first level's score is \(levelScores[0]).")

let freeLvlScore = [20,30]
levelScores += freeLvlScore

let freeLvls = 3

if levelScores.count == freeLvls{
    print("You have to buy the game in order to play its full version.")
    levelScores = []
    print("Game restarted!")
}

