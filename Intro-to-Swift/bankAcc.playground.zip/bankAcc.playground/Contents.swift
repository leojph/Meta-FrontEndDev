import Cocoa

class VirtualBanking {
    var accountType = ""
    func welcomeCostumer(){
        print("Welcome to your virtual banking system")
    }
    func accounType(){
        print("What kind of banking account would you like to open?")
        print("1. Debit account")
        print("2. Credit account")
    }
    func accType (numberPadKey : Int){
        print("The selected option is \(numberPadKey)")
        switch numberPadKey{
        case 1:
            accountType = "debit"
        case 2:
            accountType = "credit"
        default:
            print("Invalid input \(numberPadKey)")
            return
        }
        print("You have opened a \(accountType) account")
    }
}
let virtualBankSys = VirtualBanking()
virtualBankSys.welcomeCostumer()
repeat{
    virtualBankSys.accounType()
    let numberPadKey = Int.random(in: 1...3)
    virtualBankSys.accType(numberPadKey: numberPadKey)
} while virtualBankSys.accountType == ""
