import Cocoa

var password = "1234"
let passcode = Int(password)
print("The passcode of the app is \(passcode!).")

password = "hello world"
if let code = Int(password){
    print("The passcode of the app is \(code)")
}
else{
    print("Passcode in invalid!")
}

let accessCode:Int
if let code = Int(password){
    accessCode = code
}
else{
    accessCode = 1111
}
print("The passcode of the app is \(accessCode)")

let firstPassword = "hello"
let secondPassowrd = "world"
if let firstPasscode = Int(firstPassword), let secondPasscode = Int(secondPassowrd){
    print("The first passcode of the app is \(firstPasscode) and the second passcode of the app is \(secondPasscode).")
}
else{
    print("Invalid Passcodes!")
}

let firstAccessCode:Int
let secondAccessCode:Int
if let firstPasscode = Int(firstPassword), let secondPasscode = Int(secondPassowrd){
    firstAccessCode = firstPasscode
    secondAccessCode = secondPasscode
}
else{
    firstAccessCode = 1111
    secondAccessCode = 2222
}
print ("The first passcode of the app is \(firstAccessCode) and the second passcode of the app is \(secondAccessCode).")
    
