import Cocoa

let dayOfWeek = "Monday"
let dailyTemp = 75

print("Today is \(dayOfWeek). Rise and shine!")
print("The temperature on \(dayOfWeek) is \(dailyTemp)°F")

var temp  = 70

print("The temperature on \(dayOfWeek) morning is \(temp)°F.")

temp = 80

print("The temperature on \(dayOfWeek) evening is \(temp)°F.")

let weeklyTemp = 75
temp = weeklyTemp

print("The average temperature this week is \(temp)°F.")
