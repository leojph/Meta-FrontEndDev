import Cocoa

let lvlScore = 10
var gameScore = 0

gameScore += lvlScore

print("The game's score is \(gameScore).")

var levelBonusScore:Float = 10.0

levelBonusScore = 20

print("The level's bonus score is \(levelBonusScore).")

gameScore += Int(levelBonusScore)
print("The game's final score is \(gameScore).")

let lowestLvlScore = 50
let highestLvlScore = 99
let levels:Double = 10

let lvlScoreDiff = Double(highestLvlScore - lowestLvlScore)
let lvlAvgScore = lvlScoreDiff/levels

print("The level's average score is \(lvlAvgScore).")


