import Cocoa

var greeting = "Hello, playground"

print("hello everyone")
