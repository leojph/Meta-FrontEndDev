import Cocoa

var weeklyTemp:[String: Int] = [:]
weeklyTemp = ["Monday": 70, "Tuesday": 75, "Wednesday": 80, "Thursday": 85, "Friday": 90, "Saturday": 95]
weeklyTemp["Monday"]! += 20
print("The tempreture on Monday is \(weeklyTemp["Monday"]!)F")

if let temperature = weeklyTemp["Sunday"] {
  print("The temperature on Sunday is \(temperature)°F.")
} else {
  weeklyTemp["Sunday"] = 100
  print("The temperature on Sunday is \(weeklyTemp["Sunday"]!)°F.")
}
if weeklyTemp.count == 7 {
  print("You have access to the weather forecast of the whole week.")
  weeklyTemp = [:]
  print("Reset weekly temperatures for next week!")
}


